
import ItemsSection from "../ItemsSection/ItemsSection";
import Banner from "../Banner/Banner";

const Home = () => {
    return (
       
          <div>
            <Banner></Banner>
            <ItemsSection></ItemsSection>
          </div>
        
    );
};

export default Home;